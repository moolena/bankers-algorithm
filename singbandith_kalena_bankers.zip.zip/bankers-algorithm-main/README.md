# Bankers Algorithm - CPSC 351 <br>
by Kalena Singbandith 

This program contains the Banker's Algorithm which takes an input from text file and runs the algorithm checking for allocation resources and distributing as needed. 

Please refer to master branch to see code. 
